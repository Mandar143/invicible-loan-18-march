export class Client{
    id: string
    cname: string
    paddress:   string
    saddress:  string
    city: string
    state: string
    zipcode: string
    cntry: string  
    phonenumber: string
    mnumber:string
    fax:string
    email: string
    aemail: string
    waddr: string 
}