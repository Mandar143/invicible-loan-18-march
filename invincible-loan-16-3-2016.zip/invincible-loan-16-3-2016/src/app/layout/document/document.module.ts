import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DocumentRoutingModule } from './document-routing.module';
import { DocumentComponent } from './document/document.component';

import { Routes, RouterModule } from '@angular/router';
import { FormModule } from '../form/form.module';

@NgModule({
  imports: [
    CommonModule,
    DocumentRoutingModule,
    HttpClientModule,
    FormModule,
    ReactiveFormsModule
  ],
  declarations: [DocumentComponent]
})
export class DocumentModule { }
