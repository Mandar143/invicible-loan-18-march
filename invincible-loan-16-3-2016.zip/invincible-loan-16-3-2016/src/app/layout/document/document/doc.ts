export class Doc{
 
    
    dname:string
    _id:string
}