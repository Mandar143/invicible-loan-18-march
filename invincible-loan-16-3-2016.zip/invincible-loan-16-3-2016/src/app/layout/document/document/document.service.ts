import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import {Doc} from './doc';

@Injectable()
export class DocumentService {

  constructor(
 
    private http :HttpClient
    
  ) { }

  // savedata(dc:Doc){
  //   // console.log(dc)
  //   return this.http.post('http://localhost:3000/document',dc,{

  //     headers:new HttpHeaders({
  //       'Content-Type':'application/json'
  //     })
  //   })
  // }

 

  selectdoc(_id:string ,onResult:(docs)=>void) {
   //console.log(_id)
   //console.log(res)
  //  console.log(dname) 
   return this.http.post('http://localhost:3000/select',_id,{
     
      headers:new HttpHeaders({
        'Content-Type':'application/json'
      })
    }).subscribe(
      (response: Response) => onResult(response),
      err => onResult(err),
    )

  }

  updatedocument(abc){
    console.log(abc)
    let doc=new Doc()
    doc.dname=abc.dname
    doc._id=abc._id
    console.log(doc)
    return  this.http.put(`http://localhost:3000/updatedata`,doc,{
      headers: new HttpHeaders({
        'Content-Type':'application/json'
      })
  }
    )

  }

  deletedocs(_id){
    console.log(_id)
    let doc=new Doc()
    
    doc._id=_id

return  this.http.post(`http://localhost:3000/deletedoc`,doc,{
    headers: new HttpHeaders({
      'Content-Type':'application/json'
    })
  }
  )
  }



}
