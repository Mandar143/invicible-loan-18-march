import { Component, OnInit } from '@angular/core';
import { DocumentService } from './document.service';
import { HttpClient,HttpHeaders } from '@angular/common/http';
@Component({
  selector: 'app-document',
  templateUrl: './document.component.html',
  styleUrls: ['./document.component.css'],
  providers:[DocumentService]
})
export class DocumentComponent implements OnInit {
   resmsg:string
   dname:string
   dm:string
   msg:string
   arr:any
   docs:any
   _id: string
   id1:string
  constructor(
    private docservice: DocumentService,
    private http : HttpClient

  ) { 
    //  this.http.get('http://localhost:3000/document').subscribe(data => {
    //   // console.log(data)
    //   this.docs=data
    //   //location.reload();
    // })
  
  }

  ngOnInit() {
    
  }


  save(dname : string){
    // console.log(dname)
     this.arr={
       "dname":dname
     }
    console.log(this.arr)
    // this.docservice.savedata(this.arr).subscribe(
    //   res=>console.log(res),
    //   err=>console.log(err),
    //   ()=>{
    //     this.resmsg="Record Saved Successfully......"
    //   }
    // )
  }

  Onedit(_id:string)
  {
  //  console.log(dname)
  //  console.log(_id)
   this.arr={
     "_id":_id
   }
   this.docservice.selectdoc(this.arr,result=>{
    this.dm=result.dname
    this.id1=result._id

   })

   var value="Update"
  }

  updatedoc(dname:string, id:string)
  {
    // updaterec(frm){
      console.log(dname)
      let abc={
        "dname":dname,
       
        "_id":id
      }
      console.log(abc)
      
      this.docservice.updatedocument(abc).subscribe(
        res=>console.log(res),
        err=>console.log(err),
        ()=>{
          //location.reload()
          this.resmsg="Record Updated Successfully..."
        }
      )
      
    }


    Ondelete(_id:string){
      console.log(name)
      this.docservice.deletedocs(_id).subscribe(
        res=>console.log(res),
        err=>console.log(err),
        ()=>{
          //location.reload()
          this.resmsg="Record Deleted Successfully..."
        }
      )
    }

  
}
